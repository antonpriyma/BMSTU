package models

type Message struct {
	Value    string
	Position Position
	IsError  bool
}
