package models

type Fragment struct {
	Start     Position
	Following Position
}
