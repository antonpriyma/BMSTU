package main

import "github.com/AntonPriyma/BMSTU/CompilersLab4/internal/app"

func main() {
	app.Lexer()
}
